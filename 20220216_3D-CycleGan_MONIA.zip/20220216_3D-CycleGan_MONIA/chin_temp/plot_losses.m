clc
close all
clear

xlsfile = '001/loss_log_xlsx.xlsx';
[outt.num, outt.text] = xlsread(xlsfile);
maxEpoch = outt.num(end,1);
minEpoch = outt.num(1,1);
%all_epoch = linspace(minEpoch, maxEpoch, maxEpoch);
cur_epoch = minEpoch;

data = zeros(maxEpoch,1);

D_A = zeros(maxEpoch,1);
G_A = zeros(maxEpoch,1);
cycle_A = zeros(maxEpoch,1);
idt_A = zeros(maxEpoch,1);

D_A = zeros(maxEpoch,1);
G_A = zeros(maxEpoch,1);
cycle_A = zeros(maxEpoch,1);
idt_A = zeros(maxEpoch,1);

for i = 1:1:maxEpoch
    [col, row] = find(outt.num(:,1)==cur_epoch);
    tmp.data = outt.num(col,10);
    
    tmp.D_A = outt.num(col,12);
    tmp.G_A = outt.num(col,14);
    tmp.cycle_A = outt.num(col,16);
    tmp.idt_A = outt.num(col,18);
    
    tmp.D_B = outt.num(col,20);
    tmp.G_B = outt.num(col,22);
    tmp.cycle_B = outt.num(col,24);
    tmp.idt_B = outt.num(col,26);
    
    data(i,1) = mean(tmp.data);
    D_A(i,1) = mean(tmp.D_A);
    G_A(i,1) = mean(tmp.G_A);
    cycle_A(i,1) = mean(tmp.cycle_A);
    idt_A(i,1) = mean(tmp.idt_A);
    D_B(i,1) = mean(tmp.D_B);
    G_B(i,1) = mean(tmp.G_B);
    cycle_B(i,1) = mean(tmp.cycle_B);
    idt_B(i,1) = mean(tmp.idt_B);
    
    cur_epoch = cur_epoch+1;
    
    clear [col,row]
    clear tmp
end

figure
set(gcf,'color','w');
hold on
plot(D_A,'r--')
plot(D_B,'r-*')
plot(G_A,'b--')
plot(G_B,'b-*')
legend('D_A', 'D_B', 'G_A', 'G_B')
hold off
box on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
set(gcf,'color','w');

subplot(2,1,1)
hold on
plot(D_A,'r--')
plot(D_B,'r-*')
plot(G_A,'b--')
plot(G_B,'b-*')
legend('D_A', 'D_B', 'G_A', 'G_B')
hold off
box on

subplot(2,1,2)
hold on
plot(cycle_A,'r--')
plot(cycle_B,'r-*')
plot(idt_A,'b--')
plot(idt_B,'b-*')
legend('cycle_A', 'cycle_B', 'idt_A', 'idt_B')
hold off
box on

% subplot(3,1,3)
% hold on
% plot(data,'k--')
% legend('Data')
% hold off
% box on


